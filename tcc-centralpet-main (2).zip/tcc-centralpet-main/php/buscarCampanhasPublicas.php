
<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "conexao.php";

function responder($sucesso, $mensagem, $dados = null, $status = 200) {

    http_response_code($status);

    echo json_encode([
        "sucesso" => $sucesso,
        "mensagem" => $mensagem,
        "dados" => $dados
    ], JSON_UNESCAPED_UNICODE);

    exit;
}

// Somente GET
if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(false, "Método não permitido.", null, 405);
}

// Buscar todas as campanhas ativas
$resultado = supabaseRequest(
    "tb_campanha?status=eq.ativa&select=*&order=data_criacao.desc",
    "GET"
);

if (!$resultado["sucesso"]) {
    responder(
        false,
        "Não foi possível carregar as campanhas.",
        $resultado["dados"] ?? null,
        400
    );
}

$campanhas = $resultado["dados"] ?? [];

if (empty($campanhas)) {
    responder(true, "Nenhuma campanha ativa encontrada.", []);
}

// Buscar os IDs das ONGs responsáveis
$idsOngs = array_values(array_unique(
    array_filter(array_column($campanhas, "id_ong"))
));

// Buscar os nomes das ONGs
$nomesOngs = [];

if (!empty($idsOngs)) {

    $idsFormatados = implode(",", $idsOngs);

    $perfis = supabaseRequest(
        "tb_perfil_usuario?id_usuario=in.(" . $idsFormatados . ")&select=id_usuario,nome",
        "GET"
    );

    if ($perfis["sucesso"] && is_array($perfis["dados"])) {

        foreach ($perfis["dados"] as $perfil) {

            $nomesOngs[$perfil["id_usuario"]] =
                $perfil["nome"] ?? "ONG";
        }
    }
}

// Adicionar o nome da ONG em cada campanha
foreach ($campanhas as &$campanha) {

    $idOng = $campanha["id_ong"];

    $campanha["nome_ong"] =
        $nomesOngs[$idOng] ?? "ONG responsável";
}

unset($campanha);

responder(
    true,
    "Campanhas públicas carregadas com sucesso.",
    $campanhas
);
