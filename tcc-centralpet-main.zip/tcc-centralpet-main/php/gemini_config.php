<?php

$GEMINI_API_KEY = "AQ.Ab8RN6KTCtbtDqjFaCfui7mJ9cDzgK_Ohw-p_vEMIiHnD556zg";